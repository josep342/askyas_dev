import requests

data={
    "titre":"Le INFO de la C.T.I  Lance La Promotion de Carte(Carte Simple, CArte PVC)=> 15 pourcent de REDUCTION",
    "soustitre":"INFO Suite au Renouvellement des Outils de la C.T.I, son  PDG, ASKYAS Junior annonce La promotion Full, dans le but de faire gouter la Population Congolaise le Fruit de ce Matériau de la Nouvelle Génération",
    "detail":" INFO guise d'information comme stipuler ci-haut, en vue de Favoriser les Infrastructures,Associations, Ecoles et autres, la C.T.I offre une Opportunité de Conception et Impression de Qualité des Carte sur toutes leurs formes(Carte PVC(Carte d'élève, Carte d'étudiant, Carte de Membre, Carte de Service, autre) et Carte Simple(Carte de Visite, Carte MicroBadge) avec une qualité SUPERBE [au délà des imagination] avec une REDUCTION DE 15 du maché pour toute operation, pour plus d'info +243 970494397, okay",
    "photo":"kka.png",
    "type":"immo"
    }

data={
    'titre':'Adresse Physique',
    'detail':'INFO guise d information comme stipuler ci-haut, en vue de Favoriser les Infrastructures,Associations, Ecoles et autres, la C.T.I offre une Opportunité de Conception et Impression de Qualité des Carte sur toutes leurs formes(Carte PVC(Carte d élève, Carte d étudiant, Carte de Membre, Carte de Service, autre) et Carte Simple(Carte de Visite, Carte MicroBadge) avec une qualité SUPERBE [au délà des imagination] avec une REDUCTION DE 15 du maché pour toute operation, pour plus dinfo +243 970494397, okay'
}

rep=requests.post('http://0.0.0.0:5555/contact/create',json=data)

if rep.status_code==200:

    data=rep.json()
   
    print(data)

else:
    print("error")


