from fastapi import FastAPI,Depends
import asyncio
import uvicorn
from model.back import Bd

from model import back
from schema.schema import MaladieValidate, SymptomeValidate,RegleValidate

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import text
from sqlalchemy import Table,MetaData,Column,Integer,String,Float,Double,DateTime,Date,select
from sqlalchemy import and_
from sqlalchemy import or_
from sqlalchemy import update
import sqlite3

from fastapi.middleware.cors import CORSMiddleware

app=FastAPI()

app.add_middleware(

    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]

)

@app.get('/kenamel')

def index():

    return Bd().testBase()

@app.get('/contact')

def recuperation():
            
    datanew=Bd().contactSelect() 

    return {

        "data": datanew
    }

@app.post('/contact/create')

async def recuperation(data:dict):
    dataa=[]

    dataa.append(data)
    
    datanew=Bd().contactInsert(dataa)

    return {

        "data": datanew
    }

@app.get('/accueil')

def recuperation():
            
    datanew=Bd().accueilSelect() 

    return {

        "data": datanew
    }

@app.post('/accueil/create')

async def recuperation(data:dict):
    dataa=[]

    dataa.append(data)
    
    datanew=Bd().accueilInsert(dataa)

    return {

        "data": datanew
    }

@app.get('/procedure')

def recuperation():
            
    datanew=Bd().procedureSelect() 

    return {

        "data": datanew
    }

@app.post('/procedure/create')

async def recuperation(data:dict):
    dataa=[]

    dataa.append(data)
    
    datanew=Bd().procedureInsert(dataa)

    return {

        "data": datanew
    }


@app.get('/propo')

def recuperation():
            
    datanew=Bd().propoSelect() 

    return {

        "data": datanew
    }

@app.post('/propo/create')

async def recuperation(data:dict):
    dataa=[]

    dataa.append(data)
    
    datanew=Bd().propoInsert(dataa)

    return {

        "data": datanew
    }


@app.get('/actualite')

def recuperation():
            
    datanew=Bd().actualiteSelect() 

    return {

        "data": datanew
    }

@app.post('/actualite/create')

async def recuperation(data:dict):
    dataa=[]

    dataa.append(data)
    
    datanew=Bd().actualiteInsert(dataa)

    return {

        "data": datanew
    }

@app.get('/service')

async def recuperation():

    datanew=Bd().serviceSelect()

    return {

        "data": datanew
    }

@app.get('/service/conception')

async def recuperation():

    datanew=Bd().serviceSelectConception()

    return {

        "data": datanew
    }

@app.get('/service/technique')

async def recuperation():

    datanew=Bd().serviceSelectTechnique()

    return {

        "data": datanew
    }

@app.get('/service/formation')

async def recuperation():

    datanew=Bd().serviceSelectFormation()

    return {

        "data": datanew
    }


@app.post('/service/create')

async def recuperation(data:dict):
    dataa=[]

    dataa.append(data)

    datanew=Bd().serviceInsert(dataa)

    return {

        "data": datanew
    }

@app.get('/annonce')

async def recuperation():

    datanew=Bd().annonceSelect()

    return {

        "data": datanew
    }

@app.get('/annonce/conception')

async def recuperation():

    datanew=Bd().annonceSelectConception()

    return {

        "data": datanew
    }

@app.get('/annonce/autre')

async def annonceSelectInfo():

    datanew=Bd().annonceSelectAutre()

    return {

        "data": datanew
    }

@app.post('/annonce/create')

async def recuperation(data:dict):

    dataa=[]

    dataa.append(data)

    datanew=Bd().annonceInsert(dataa)

    return {

        "data": datanew
    }


@app.get('/partenariat')

async def annonceSelectInfo():

    datanew=Bd().partenariatSelect()

    return {

        "data": datanew
    }

@app.post('/partenariat/create')

async def recuperation(data:dict):

    dataa=[]

    dataa.append(data)

    datanew=Bd().annonceInsert(dataa)

    return {

        "data": datanew
    }


@app.get('/contrat/projet')

async def recuperation():

    datanew=[]

    datanew=Bd().contratselect1()

    return {

        "data": datanew
    }

@app.get('/contrat/autres')

async def recuperation():

    datanew=[]

    datanew=Bd().contratselect2()

    return {

        "data": datanew
    }

#if __name__=='__main__':

#    uvicorn.run('main:app',host='0.0.0.0',port=5555,reload=True)

