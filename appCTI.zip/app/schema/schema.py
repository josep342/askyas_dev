from pydantic import BaseModel,EmailStr,Field,conint
from typing import Literal

class MaladieValidate(BaseModel):

    description:str=Field(...,min_length=2,description="nom de la maladie")

class SymptomeValidate(BaseModel):

    description:str=Field(...,min_length=2,description="nom du symptome")
    id_maladie:float=Field(gt=0)

class RegleValidate(BaseModel):

    description:str=Field(...,min_length=2,description="nom du symptome")
    id_maladie:float=Field(gt=0)

