from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import text
from sqlalchemy import Table,MetaData,Column,Integer,String,Float,Double,DateTime,Date,select
from sqlalchemy import and_
from sqlalchemy import or_
from sqlalchemy import update
import sqlite3

import random 

from datetime import datetime

class Bd():

    def __init__(self):

        global engine,sessionLocal,metadata,datte,datettime,date

        datte=datetime.now().strftime('%Y-%m-%d')
        date=datetime.now().strftime('%Y-%m-%d')
        datettime=datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        urlBAse="mysql+mysqlconnector://askyas:askyas@localhost:3306/siteCTI "
        engine=create_engine(urlBAse)

        #urlBAse="mysql+mysqlconnector://askyas:askyas@localhost:3306/kenamelBD.db"

        #engine=create_engine("sqlite:///kenamelBD.db")
        #metadata=MetaData()

        sessionLocal=sessionmaker(autocommit=False,autoflush=False,bind=engine)

        metadata=MetaData()

        ccon=engine.connect()
        
    def testBase(self):  

        
        try: 

            with sessionLocal() as session:
                res=session.execute(text("SELECT DATABASE()"))

                rep=res.fetchone()  

        except Exception as e:

            print(e)
            rep=""

        
        return rep

    def contactInsert(self,data:dict):

        dataaNew=[]

        for li in data:

            li['ddate']=datetime.strptime(datetime.now().strftime('%Y-%m-%d'),'%Y-%m-%d')
    
            dataaNew.append(li)


        t_bloc=Table("contact",metadata,

            Column('id',Integer,primary_key=True,autoincrement=True),
            Column('titre',String),
            Column('detail',String),
            Column('ddate',Date)
        )

        try:

            with sessionLocal() as session:

                session.execute(t_bloc.insert(),dataaNew)

                session.commit()

                etatReq=True

                error=""

        except Exception as e:

            etatReq=False
            error=e
        
        return {'etat':etatReq,'info':error}

    def contactSelect(self):
        
        tabdata=[]

        try:
            table1=Table("contact",metadata,autoload_with=engine)
        
            with engine.connect() as con:

                res=con.execute(select(table1))

                tabval=res.mappings().all()

                if tabval:

                    etat=True

                    tabdata.append(tabval)

                else:

                    etat=False

                    tabval=[]

        except Exception as e:

            error=e
            tabval=[]
                
        return tabval
    

    def accueilInsert(self,data:dict):

        dataaNew=[]

        for li in data:

            li['ddate']=datetime.strptime(datetime.now().strftime('%Y-%m-%d'),'%Y-%m-%d')
    
            dataaNew.append(li)


        t_bloc=Table("accueil",metadata,

            Column('id',Integer,primary_key=True,autoincrement=True),
            Column('titre',String),
            Column('detail',String),
            Column('ddate',Date)
        )

        try:

            with sessionLocal() as session:

                session.execute(t_bloc.insert(),dataaNew)

                session.commit()

                etatReq=True

                error=""

        except Exception as e:

            etatReq=False
            error=e
        
        return {'etat':etatReq,'info':error}

    def accueilSelect(self):
        
        tabdata=[]

        try:
            table1=Table("accueil",metadata,autoload_with=engine)
        
            with engine.connect() as con:

                res=con.execute(select(table1))

                tabval=res.mappings().all()

                if tabval:

                    etat=True

                    tabdata.append(tabval)

                else:

                    etat=False

                    tabval=[]

        except Exception as e:

            error=e
            tabval=[]
                
        return tabval
    
    def procedureInsert(self,data:dict):

        dataaNew=[]

        for li in data:

            li['ddate']=datetime.strptime(datetime.now().strftime('%Y-%m-%d'),'%Y-%m-%d')
    
            dataaNew.append(li)


        t_bloc=Table("procedure",metadata,

            Column('id',Integer,primary_key=True,autoincrement=True),
            Column('titre',String),
            Column('detail1',String),
            Column('detail2',String),
            Column('detail3',String),
            Column('detail4',String),
            Column('ddate',Date)
        )

        try:

            with sessionLocal() as session:

                session.execute(t_bloc.insert(),dataaNew)

                session.commit()

                etatReq=True

                error=""

        except Exception as e:

            etatReq=False
            error=e
        
        return {'etat':etatReq,'info':error}

    def procedureSelect(self):
        
        tabdata=[]

        try:
            table1=Table("procedure",metadata,autoload_with=engine)
        
            with engine.connect() as con:

                res=con.execute(select(table1))

                tabval=res.mappings().all()

                if tabval:

                    etat=True

                    tabdata.append(tabval)

                else:

                    etat=False

                    tabval=[]

        except Exception as e:

            error=e
            tabval=[]
                
        return tabval
    

    def propoInsert(self,data:dict):

        dataaNew=[]

        for li in data:

            li['ddate']=datetime.strptime(datetime.now().strftime('%Y-%m-%d'),'%Y-%m-%d')
    
            dataaNew.append(li)


        t_bloc=Table("propos",metadata,

            Column('id',Integer,primary_key=True,autoincrement=True),
            Column('titre',String),
            Column('detail',String),
            Column('ddate',Date)
        )

        try:

            with sessionLocal() as session:

                session.execute(t_bloc.insert(),dataaNew)

                session.commit()

                etatReq=True

                error=""

        except Exception as e:

            etatReq=False
            error=e
        
        return {'etat':etatReq,'info':error}

    def propoSelect(self):
        
        tabdata=[]

        try:
            table1=Table("propos",metadata,autoload_with=engine)
        
            with engine.connect() as con:

                res=con.execute(select(table1))

                tabval=res.mappings().all()

                if tabval:

                    etat=True

                    tabdata.append(tabval)

                else:

                    etat=False

                    tabval=[]

        except Exception as e:

            error=e
            tabval=[]
                
        return tabval
    
    def actualiteInsert(self,data:dict):

        dataaNew=[]

        for li in data:

            li['ddate']=datetime.strptime(datetime.now().strftime('%Y-%m-%d'),'%Y-%m-%d')
    
            dataaNew.append(li)


        t_bloc=Table("actualite",metadata,

            Column('id',Integer,primary_key=True,autoincrement=True),
            Column('titre',String),
            Column('soustitre',String),
            Column('detail',String),
            Column('photo',String),
            Column('ddate',Date)
        )

        try:

            with sessionLocal() as session:

                session.execute(t_bloc.insert(),dataaNew)

                session.commit()

                etatReq=True

                error=""

        except Exception as e:

            etatReq=False
            error=e
        
        return {'etat':etatReq,'info':error}

    def actualiteSelect(self):
        
        tabdata=[]

        try:
            table1=Table("actualite",metadata,autoload_with=engine)
        
            with engine.connect() as con:

                res=con.execute(select(table1))

                tabval=res.mappings().all()

                if tabval:

                    etat=True

                    tabdata.append(tabval)

                else:

                    etat=False

                    tabval=[]

        except Exception as e:

            error=e
            tabval=[]
                
        return tabval
    
    def serviceInsert(self,data:dict):

        dataaNew=[]

        for li in data:

            li['ddate']=datetime.strptime(datetime.now().strftime('%Y-%m-%d'),'%Y-%m-%d')
    
            dataaNew.append(li)


        t_bloc=Table("service",metadata,

            Column('id',Integer,primary_key=True,autoincrement=True),
            Column('titre',String),
            Column('soustitre',String),
            Column('detail',String),
            Column('photo',String),
            Column('type',String),
            Column('ddate',Date)
        )

        try:

            with sessionLocal() as session:

                session.execute(t_bloc.insert(),dataaNew)

                session.commit()

                etatReq=True

                error=""

        except Exception as e:

            etatReq=False
            error=e
        
        return {'etat':etatReq,'info':error}

    def serviceSelect(self):

        tabdata=[]

        table1=Table("service",metadata,autoload_witah=engine)
       
        with engine.connect() as con:

            res=con.execute(select(table1))

            tabval=res.mappings().all()

            if tabval:

                etat=True

                tabdata.append(tabval)

            else:

                etat=False

                tabval=[]

                
            return tabval #tabval,etat

    def serviceSelectConception(self):

        tabdata=[]

        table1=Table("service",metadata,autoload_with=engine)
       
        with engine.connect() as con:

            res=con.execute(select(table1).where(table1.c.type=="0"))

            tabval=res.mappings().all()

            if tabval:

                etat=True

                tabdata.append(tabval)

            else:

                etat=False

                tabval=[]

                
            return tabval
    
    def serviceSelectTechnique(self):

        tabdata=[]

        table1=Table("service",metadata,autoload_with=engine)
       
        with engine.connect() as con:

            res=con.execute(select(table1).where(table1.c.type=="1"))

            tabval=res.mappings().all()

            if tabval:

                etat=True

                tabdata.append(tabval)

            else:

                etat=False

                tabval=[]

                
            return tabval
    
    def serviceSelectFormation(self):

        tabdata=[]

        table1=Table("service",metadata,autoload_with=engine)
       
        with engine.connect() as con:

            res=con.execute(select(table1).where(table1.c.type=="2"))

            tabval=res.mappings().all()

            if tabval:

                etat=True

                tabdata.append(tabval)

            else:

                etat=False

                tabval=[]

                
            return tabval
        
    def annonceInsert(self,data:dict):

        dataaNew=[]

        for li in data:

            li['ddate']=datetime.strptime(datetime.now().strftime('%Y-%m-%d'),'%Y-%m-%d')
    
            dataaNew.append(li)


        t_bloc=Table("annonce",metadata,

            Column('id',Integer,primary_key=True,autoincrement=True),
            Column('titre0',String), 
            Column('titre',String),
            Column('soustitre',String),
            Column('detail',String),
            Column('photo',String),
            Column('type',String),
            Column('lien',String),
            Column('ddate',Date)
        )

        try:

            with sessionLocal() as session:

                session.execute(t_bloc.insert(),dataaNew)

                session.commit()

                etatReq=True

                error=""

        except Exception as e:

            etatReq=False
            error=e
        
        return {'etat':etatReq,'info':error}

    def annonceSelect(self):

        tabdata=[]

        table1=Table("annonce",metadata,autoload_with=engine)
       
        with engine.connect() as con:

            res=con.execute(select(table1))

            tabval=res.mappings().all()

            if tabval:

                etat=True

                tabdata.append(tabval)

            else:

                etat=False

                tabval=[]

                
            return tabval #tabval,etat

    def annonceSelectConception(self):

        tabdata=[]

        table1=Table("annonce",metadata,autoload_with=engine)
       
        with engine.connect() as con:

            res=con.execute(select(table1).where(table1.c.type=="0"))

            tabval=res.mappings().all()

            if tabval:

                etat=True

                tabdata.append(tabval)

            else:

                etat=False

                tabval=[]

                
            return tabval
    
    def annonceSelectAutre(self):

        tabdata=[]

        table1=Table("annonce",metadata,autoload_with=engine)
       
        with engine.connect() as con:

            res=con.execute(select(table1).where(table1.c.type=="1"))

            tabval=res.mappings().all()

            if tabval:

                etat=True

                tabdata.append(tabval)

            else:

                etat=False

                tabval=[]

                
            return tabval
    

    def annonceSelectAutres(self):

        tabdata=[]

        table1=Table("annonce",metadata,autoload_with=engine)
       
        with engine.connect() as con:

            res=con.execute(select(table1).where(table1.c.type=="autre"))

            tabval=res.mappings().all()

            if tabval:

                etat=True

                tabdata.append(tabval)

            else:

                etat=False

                tabval=[]

                
            return tabval
    

    def partenariatSelect(self):
        
        tabdata=[]

        try:
            table1=Table("partenariat",metadata,autoload_with=engine)
        
            with engine.connect() as con:

                res=con.execute(select(table1))

                tabval=res.mappings().all()

                if tabval:

                    etat=True

                    tabdata.append(tabval)

                else:

                    etat=False

                    tabval=[]

        except Exception as e:

            error=e
            tabval=[]
                
        return tabval
    
    def contratselect1(self):

        tabval=[]

        try:
                
            t_bloc=Table("contrat",metadata,

                Column('id',Integer,primary_key=True,autoincrement=True),
                Column('titre',String), 
                Column('infoClient',String),
                Column('adressPharma',String),
                Column('temoignage',String),
                Column('photo',String),
                Column('type',String),
                Column('etat',bool),
                Column('ddate',Date)
            )

        except:

            t_bloc=Table("contrat",metadata,autoload_with=engine)
        

        with engine.connect() as con:

                res=con.execute(select(t_bloc).where(t_bloc.c.etat==True))

                tabval=res.mappings().all()

        
        return  tabval


    def contratselect2(self):

        tabval=[]

        try:
                
            t_bloc=Table("contrat",metadata,

                Column('id',Integer,primary_key=True,autoincrement=True),
                Column('titre',String), 
                Column('infoClient',String),
                Column('adressPharma',String),
                Column('temoignage',String),
                Column('photo',String),
                Column('type',String),
                Column('etat',bool),
                Column('ddate',Date)
            )

        except:

            t_bloc=Table("contrat",metadata,autoload_with=engine)
        

        with engine.connect() as con:

                res=con.execute(select(t_bloc).where(t_bloc.c.etat==False))

                tabval=res.mappings().all()

        
        return  tabval